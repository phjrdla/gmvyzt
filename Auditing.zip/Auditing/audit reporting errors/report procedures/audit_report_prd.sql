-- "Set define off" turns off substitution variables. 
Set define off; 

CREATE OR REPLACE PROCEDURE DZDBA.audit_report_prd  AS

	v_datum			VARCHAR2(25)  := to_char(sysdate,'DD MONTH YY');
	v_start			VARCHAR2(25)  := to_char(sysdate,'HH24:MI:SS') ;
	v_einde			VARCHAR2(25)  := to_char(sysdate,'HH24:MI:SS') ;
	v_database		VARCHAR2(25)  := 'UNKNOWN'                     ;

        v_query1                VARCHAR2(4000)                                 ;

        v_query2a               VARCHAR2(4400)                                 ;
        v_query2b               VARCHAR2(4400)                                 ;
        v_query2c               VARCHAR2(4400)                                 ;

        v_query3a               VARCHAR2(4000)                                 ;
        v_query3b               VARCHAR2(4000)                                 ;
        v_query3c               VARCHAR2(4000)                                 ;


 BEGIN NULL;
htp.prn('
');
htp.prn('
');
htp.prn('
');


select * into v_database from global_name@prd_lnk;

v_query1 := 'SELECT OWNER||''.''||OBJECT_NAME Object,
                    DECODE (ALT, ''A/A'', '' ON'', ''OFF'') ALT,
                    DECODE (AUD, ''A/A'', '' ON'', ''OFF'') AUD,
                    DECODE (COM, ''A/A'', '' ON'', ''OFF'') COM,
                    DECODE (DEL, ''A/A'', '' ON'', ''OFF'') DEL,
                    DECODE (GRA, ''A/A'', '' ON'', ''OFF'') GRA,
                    DECODE (IND, ''A/A'', '' ON'', ''OFF'') IND,
                    DECODE (INS, ''A/A'', '' ON'', ''OFF'') INS,
                    DECODE (LOC, ''A/A'', '' ON'', ''OFF'') LOC,
                    DECODE (REN, ''A/A'', '' ON'', ''OFF'') REN,
                    DECODE (SEL, ''A/A'', '' ON'', ''OFF'') SEL,
                    DECODE (UPD, ''A/A'', '' ON'', ''OFF'') UPD,
                    DECODE (REF, ''A/A'', '' ON'', ''OFF'') REF,
                    DECODE (EXE, ''A/A'', '' ON'', ''OFF'') EXE,
                    DECODE (CRE, ''A/A'', '' ON'', ''OFF'') CRE,
                    DECODE (REA, ''A/A'', '' ON'', ''OFF'') REA,
                    DECODE (WRI, ''A/A'', '' ON'', ''OFF'') WRI
            FROM DBA_OBJ_AUDIT_OPTS@prd_lnk
            WHERE owner = ''MSRG02'' and object_name in (''RQHA'', ''RQJA'' , ''RQM'')';

v_query2a := 'SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''UPD'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate)
                        AND action_name = ''UPDATE'' )
             FROM hisaudit.his_audit_object@prd_lnk a
             where auditdate = trunc(sysdate)
             UNION
             SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''INS'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate)
                        AND action_name = ''INSERT'' )
             FROM hisaudit.his_audit_object@prd_lnk a
             where auditdate = trunc(sysdate)
             UNION
             SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''DEL'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate)
                        AND action_name = ''DELETE'' )
              FROM hisaudit.his_audit_object@prd_lnk a
              where auditdate = trunc(sysdate)';

v_query2b := 'SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''UPD'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate-1)
                        AND action_name = ''UPDATE'' )
             FROM hisaudit.his_audit_object@prd_lnk a
             where auditdate = trunc(sysdate-1)
             UNION
             SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''INS'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate-1)
                        AND action_name = ''INSERT'' )
             FROM hisaudit.his_audit_object@prd_lnk a
             where auditdate = trunc(sysdate-1)
             UNION
             SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''DEL'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate-1)
                        AND action_name = ''DELETE'' )
              FROM hisaudit.his_audit_object@prd_lnk a
              where auditdate = trunc(sysdate-1)';

v_query2c := 'SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''UPD'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate-2)
                        AND action_name = ''UPDATE'' )
             FROM hisaudit.his_audit_object@prd_lnk a
             where auditdate = trunc(sysdate-2)
             UNION
             SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''INS'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate-2)
                        AND action_name = ''INSERT'' )
             FROM hisaudit.his_audit_object@prd_lnk a
             where auditdate = trunc(sysdate-2)
             UNION
             SELECT DISTINCT a.owner || ''.'' || a.obj_name object,
                    ''DEL'' statement,
                    ( SELECT count(*)
                      FROM hisaudit.his_audit_object@prd_lnk
                      WHERE obj_name = a.obj_name
                        AND auditdate = trunc(sysdate-2)
                        AND action_name = ''DELETE'' )
              FROM hisaudit.his_audit_object@prd_lnk a
              where auditdate = trunc(sysdate-2)';

v_query3a := 'SELECT distinct a.sessionid, a.username, a.obj_name,
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate)
       AND action_name = ''UPDATE''
       AND sessionid = a.sessionid ),
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate)
       AND action_name = ''INSERT''
       AND sessionid = a.sessionid ),
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate)
       AND action_name = ''DELETE''
       AND sessionid = a.sessionid )
FROM hisaudit.his_audit_object@prd_lnk a
where auditdate = trunc(sysdate)';

v_query3b := 'SELECT distinct a.sessionid, a.username, a.obj_name,
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate-1)
       AND action_name = ''UPDATE''
       AND sessionid = a.sessionid ),
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate-1)
       AND action_name = ''INSERT''
       AND sessionid = a.sessionid ),
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate-1)
       AND action_name = ''DELETE''
       AND sessionid = a.sessionid )
FROM hisaudit.his_audit_object@prd_lnk a
where auditdate = trunc(sysdate-1)';

v_query3c := 'SELECT distinct a.sessionid, a.username, a.obj_name,
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate-2)
       AND action_name = ''UPDATE''
       AND sessionid = a.sessionid ),
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate-2)
       AND action_name = ''INSERT''
       AND sessionid = a.sessionid ),
  ( SELECT count(*)
      FROM hisaudit.his_audit_object@prd_lnk
     WHERE obj_name = a.obj_name
       AND auditdate = trunc(sysdate-2)
       AND action_name = ''DELETE''
       AND sessionid = a.sessionid )
FROM hisaudit.his_audit_object@prd_lnk a
where auditdate = trunc(sysdate-2)';

v_einde := to_char(sysdate,'HH24:MI:SS') ;


htp.prn('

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Audit Report</title>
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style2 {
	font-weight: bold;
	font-size: 12px;
}

body,td {
	font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
}
tr {
   border: 1px;
}
th {
	font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
        background-color: #C7C78D;
        align: center;

}
.style3 {font-size: 14px}
.style4 {font-size: 10px}
.style5 {font-size: 12px}
.style7 {font-size: 12px; font-weight: bold; }
.style8 {font-size: 12px; font-weight: bold;}
.style14 {font-size: 12px; color: #666666; }
-->
</style>
</head>
<body>
<table width="800" height="550" border="0" cellspacing="0">
  <tr>
    <td colspan="3" valign="top"><table width="800" border="0">
      <tr>
        <td width="20">&nbsp;</td>
        <td colspan="3"><div align="center" class="style1">
          <div align="left" class="style3">
            <div align="right">AUDITING REPORT </div>
          </div>
        </div></td>
        <td width="20">&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td height="1" colspan="3" bgcolor="#C7C78D"></td>
        <td></td>
      </tr>
      <tr>
        <td width="20">&nbsp;</td>
        <td colspan="3" align="left" valign="top">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="2" align="left" valign="top">
              <table width="250" border="1" cellspacing="0" bordercolor="#C7C78D">
                <tr bgcolor="#C7C78D">
                  <td><div align="left"><span class="style2">Index</span></div></td>
                </tr>
                <tr>
                  <td><br>
                      <ol>
                        <li class="style8">Audited Objects</li>
                        <li class="style8">Total Transactions</li>
                        <li class="style8">Transactions By Session</li>
                    </ol></td>
                </tr>
              </table>
              </td>
        <td width="486" align="right" valign="top"><table width="215" border="1" cellspacing="0" bordercolor="#C7C78D" bgcolor="#C7C78D">
          <tr>
            <td><span class="style2">Date:</span></td>
            <td bgcolor="#FFFFFF"><span class="style14">');
htp.prn( v_datum );
htp.prn('</span></td>
          </tr>
          <tr>
            <td><span class="style2">Start time</span></td>
            <td bgcolor="#FFFFFF"><span class="style14">');
htp.prn( v_start );
htp.prn('</span></td>
          </tr>
          <tr>
            <td><span class="style2">Stop time:</span></td>
            <td bgcolor="#FFFFFF"><span class="style14">');
htp.prn( v_einde );
htp.prn('</span></td>
          </tr>
          <tr>
            <td><span class="style2">Database: </span></td>
            <td bgcolor="#FFFFFF"><span class="style14">');
htp.prn( v_database );
htp.prn('</span></td>
          </tr>
        </table></td>
        <td width="20">&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3" align="left" valign="top">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3"><span class="style7">1. Audited Objects </span></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td colspan="3" bgcolor="#C7C78D"></td>
        <td height="1"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3" valign="top" align="center">
          <br>

<!-- Tabel status auditing -->

<TABLE bgcolor="white">
  <TR>
    <TH>Object</TH>
    <TH>Alter</TH>
    <TH>Audit</TH>
    <TH>Com</TH>
    <TH>Delete</TH>
    <TH>Grant</TH>
    <TH>Index</TH>
    <TH>Insert</TH>
    <TH>Loc</TH>
    <TH>Ren</TH>
    <TH>Select</TH>
    <TH>Update</TH>
    <TH>REF</TH>
    <TH>Execute</TH>
    <TH>Create</TH>
    <TH>Read</TH>
    <TH>Write</TH>
  </TR>
  ');

    owa_util.cellsprint(v_query1);

htp.prn('
</TABLE>

<!-- Einde -->

         <br>
       </td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3"><span class="style5"><strong>2. Total Transactions</strong></span></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td height="1" colspan="3" bgcolor="#C7C78D"></td>
        <td></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="center" valign="top" width="30%">
          <br>

<!-- Tabel session auditing totals-->

<TABLE border="1" bordercolor="#C7C78D" cellspacing="0">
  <TR>
    <TH colspan="3">
');

htp.print(to_char(sysdate,'DD-MM-YYYY'));

htp.prn('
    </TH>
  <TR>
  <TR>
    <TH>Object</TH>
    <TH>Statement</TH>
    <TH>Executions</TH>
  </TR>
  ');

  owa_util.cellsprint(v_query2a,10000);

htp.prn('
</TABLE>

<!-- Einde -->

          <br>
        </td>
        <td align="center" valign="top" width="30%">
          <br>

<!-- Tabel session auditing totals-->

<TABLE border="1" bordercolor="#C7C78D" cellspacing="0">
 <TR>
     <TH colspan="3">
');

htp.print(to_char(sysdate-1,'DD-MM-YYYY'));

htp.prn('
     </TH>
  <TR>
  <TR>
    <TH>Object</TH>
    <TH>Statement</TH>
    <TH>Executions</TH>
  </TR>
  ');

  owa_util.cellsprint(v_query2b,10000);

htp.prn('
</TABLE>

<!-- Einde -->

          <br>
        </td>
        <td align="center" valign="top" width="30%">
          <br>

<!-- Tabel session auditing totals-->

<TABLE border="1" bordercolor="#C7C78D" cellspacing="0">
 <TR>
     <TH colspan="3">
');

htp.print(to_char(sysdate-2,'DD-MM-YYYY'));

htp.prn('
     </TH>
  <TR>
  <TR>
    <TH>Object</TH>
    <TH>Statement</TH>
    <TH>Executions</TH>
  </TR>
  ');

  owa_util.cellsprint(v_query2c,10000);

htp.prn('
</TABLE>

<!-- Einde -->

          <br>
        </td>

        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3"><span class="style5"><strong>3. Transactions By Session </strong></span></td>
        <td>&nbsp;</td>
      </tr>

      <tr>
        <td></td>
        <td height="1" colspan="3" bgcolor="#C7C78D"></td>
        <td></td>
      </tr>
	  <tr>
	   <td>&nbsp;</td>
        <td align="center" valign="top" width="30%">
          <br>

<!-- Tabel session auditing -->

<TABLE border="1" bordercolor="#C7C78D" cellspacing="0">
  <TR>
    <TH colspan="6">
');

htp.print(to_char(sysdate,'DD-MM-YYYY'));

htp.prn('
    </TH>
  </TR>
  <TR>
    <TH>SessionID</TH>
    <TH>Username</TH>
    <TH>Object</TH>
    <TH>Update</TH>
    <TH>Insert</TH>
    <TH>Delete</TH>
  </TR>
  ');

  owa_util.cellsprint(v_query3a, 10000);

htp.prn('
</TABLE>

<!-- Einde -->

          <br>
        </td>
        <td align="center" width="30%" valign="top">
          <br>

<!-- Tabel session auditing -->

<TABLE border="1" bordercolor="#C7C78D" cellspacing="0">
  <TR>
    <TH colspan="6">
');

htp.print(to_char(sysdate-1,'DD-MM-YYYY'));

htp.prn('
    </TH>
  </TR>
  <TR>
    <TH>SessionID</TH>
    <TH>Username</TH>
    <TH>Object</TH>
    <TH>Update</TH>
    <TH>Insert</TH>
    <TH>Delete</TH>
  </TR>
  ');

  owa_util.cellsprint(v_query3b, 10000);

htp.prn('
</TABLE>

<!-- Einde -->

          <br>
        </td>
        <td align="center" valign="top" width="30%">
          <br>

<!-- Tabel session auditing -->

<TABLE border="1" bordercolor="#C7C78D" cellspacing="0">
  <TR>
    <TH colspan="6">
');

htp.print(to_char(sysdate-2,'DD-MM-YYYY'));

htp.prn('
    </TH>
  </TR>
  <TR>
    <TH>SessionID</TH>
    <TH>Username</TH>
    <TH>Object</TH>
    <TH>Update</TH>
    <TH>Insert</TH>
    <TH>Delete</TH>
  </TR>
  ');

  owa_util.cellsprint(v_query3c, 10000);

htp.prn('
</TABLE>

<!-- Einde -->

          <br>
        </td>

        <td>&nbsp;</td>
	</tr>
    </table></td>
  </tr>
</table>
</body>
</html>
');
 END;
/


