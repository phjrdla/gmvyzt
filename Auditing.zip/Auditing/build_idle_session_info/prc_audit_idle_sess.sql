create or replace PROCEDURE         "AUDIT_IDLE_SESS" (P_DB_NAME VARCHAR2) AS

  v_datum		  VARCHAR2(25)  := to_char(sysdate,'DD MONTH YY');
  v_start		  VARCHAR2(25)  := to_char(sysdate,'HH24:MI:SS') ;
  v_einde		  VARCHAR2(25)  := to_char(sysdate,'HH24:MI:SS') ;
  v_database		  VARCHAR2(25)  := 'UNKNOWN'                     ;

  v_query1                VARCHAR2(32000)                                 ;
  v_query2                VARCHAR2(32000)                                 ;
  v_query3                VARCHAR2(32000)                                 ;
  v_query4                VARCHAR2(32000)                                 ;

  TYPE RefCurTyp IS REF CURSOR;
  curs_var RefCurTyp;

 BEGIN NULL;
htp.prn('
');
htp.prn('
');
htp.prn('
');

v_query4 := 'SELECT global_name from global_name@'||p_db_name||'_lnk';

OPEN curs_var FOR v_query4;
FETCH curs_var INTO v_database;
CLOSE curs_var;

v_query1 := 'SELECT SID, USERNAME, to_char(LOGON_TIME,''dd/mm/yyyy hh24:mi:ss''),'||
                   'floor(IDLE_TIME/3600)||'':''|| floor(mod(IDLE_TIME,3600)/60)||'':''|| mod(mod(IDLE_TIME,3600),60) idle,'||
                   'PROGRAM, LOCKS, to_char(LAST_RUN,''dd/mm/yyyy hh24:mi:ss'')'||
            'FROM dzdba.idle_session_info@'||p_db_name||'_lnk WHERE STATUS = ''INACTIVE'' ORDER BY USERNAME, idle_time desc';
            
v_query2 := 'SELECT SID, USERNAME, to_char(LOGON_TIME,''dd/mm/yyyy hh24:mi:ss''),'||
                   'floor(IDLE_TIME/3600)||'':''|| floor(mod(IDLE_TIME,3600)/60)||'':''|| mod(mod(IDLE_TIME,3600),60) idle,'||
                   'PROGRAM, LOCKS, to_char(LAST_RUN,''dd/mm/yyyy hh24:mi:ss'')'||
            'FROM dzdba.idle_session_info@'||p_db_name||'_lnk WHERE STATUS = ''NOT EXISTS'' ORDER BY USERNAME, idle_time desc';
            
v_query3 := 'SELECT SID, USERNAME, to_char(LOGON_TIME,''dd/mm/yyyy hh24:mi:ss''),'||
                   'floor(IDLE_TIME/3600)||'':''|| floor(mod(IDLE_TIME,3600)/60)||'':''|| mod(mod(IDLE_TIME,3600),60) idle,'||
                   'PROGRAM, LOCKS, to_char(LAST_RUN,''dd/mm/yyyy hh24:mi:ss'')'||
            'FROM dzdba.idle_session_info@'||p_db_name||'_lnk WHERE STATUS NOT IN (''INACTIVE'',''NOT EXISTS'') ORDER BY USERNAME, idle_time desc';
            

v_einde := to_char(sysdate,'HH24:MI:SS') ;


htp.prn('

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Idle sessions</title>
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style2 {
	font-weight: bold;
	font-size: 12px;
}

body,td {
	font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
}
tr {
   border: 1px;
}
th {
	font-family: Arial, Helvetica, sans-serif;
        font-size: 12px;
        background-color: #C7C78D;
        align: center;

}
.style3 {font-size: 14px}
.style4 {font-size: 10px}
.style5 {font-size: 12px}
.style7 {font-size: 12px; font-weight: bold; }
.style8 {font-size: 12px; font-weight: bold;}
.style14 {font-size: 12px; color: #666666; }
-->
</style>
</head>
<body>
<table width="800" height="550" border="0" cellspacing="0">
  <tr>
    <td colspan="3" valign="top"><table width="800" border="0">
      <tr>
        <td width="20">&nbsp;</td>
        <td colspan="3"><div align="center" class="style1">
          <div align="left" class="style3">
            <div align="right">Idle sessions on '||p_db_name||' </div>
          </div>
        </div></td>
        <td width="20">&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td height="1" colspan="3" bgcolor="#C7C78D"></td>
        <td></td>
      </tr>
      <tr>
        <td width="20">&nbsp;</td>
        <td colspan="3" align="left" valign="top">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="2" align="left" valign="top">
              <table width="250" border="1" cellspacing="0" bordercolor="#C7C78D">
                <tr bgcolor="#C7C78D">
                  <td><div align="left"><span class="style2">Index</span></div></td>
                </tr>
                <tr>
                  <td><br>
                      <ol>
                        <li class="style8">Inactive SESSIONS</li>
                        <li class="style8">SESSIONS no longer in DB</li>
                        <li class="style8">SESSIONS with other STATUS</li>
                    </ol></td>
                </tr>
              </table>
        </td>
        <td width="486" align="right" valign="top"><table width="215" border="1" cellspacing="0" bordercolor="#C7C78D" bgcolor="#C7C78D">
          <tr>
            <td><span class="style2">Date:</span></td>
            <td bgcolor="#FFFFFF"><span class="style14">');
htp.prn( v_datum );
htp.prn('</span></td>
          </tr>
          <tr>
            <td><span class="style2">Start time</span></td>
            <td bgcolor="#FFFFFF"><span class="style14">');
htp.prn( v_start );
htp.prn('</span></td>
          </tr>
          <tr>
            <td><span class="style2">Stop time:</span></td>
            <td bgcolor="#FFFFFF"><span class="style14">');
htp.prn( v_einde );
htp.prn('</span></td>
          </tr>
          <tr>
            <td><span class="style2">Database: </span></td>
            <td bgcolor="#FFFFFF"><span class="style14">');
htp.prn( v_database );
htp.prn('</span></td>
          </tr>
        </table></td>
        <td width="20">&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3" align="left" valign="top">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3"><span class="style7">1. Inactive SESSIONS </span></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td colspan="3" bgcolor="#C7C78D"></td>
        <td height="1"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3" valign="top" align="center">
          <br>

<!-- Tabel Inactive sessions -->

          <TABLE bgcolor="white">
          <TR>
           <TH>Session ID.</TH>
           <TH>Username</TH>
           <TH>Logged on since</TH>
           <TH>Total idle time</TH>
           <TH>Program</TH>
           <TH>Locks present</TH>
           <TH>Last checked on</TH>
          </TR>
      ');

owa_util.cellsprint(v_query1);

htp.prn('
          </TABLE>

<!-- Einde -->

          <br>
        </td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3"><span class="style5"><strong>2. SESSIONS no longer in DB</strong></span></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td colspan="3" bgcolor="#C7C78D"></td>
        <td height="1"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3" valign="top" align="center">
          <br>

<!-- Tabel Sesions no longer in DB -->

          <TABLE bgcolor="white">
          <TR>
           <TH>Session ID.</TH>
           <TH>Username</TH>
           <TH>Logged on since</TH>
           <TH>Total idle time</TH>
           <TH>Program</TH>
           <TH>Locks present</TH>
           <TH>Last checked on</TH>
          </TR>
      ');

owa_util.cellsprint(v_query2);

htp.prn('
          </TABLE>

<!-- Einde -->

          <br>
        </td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3"><span class="style5"><strong>2. SESSIONS with other STATUS</strong></span></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td></td>
        <td colspan="3" bgcolor="#C7C78D"></td>
        <td height="1"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3" valign="top" align="center">
          <br>

<!-- Tabel Sesions with other status -->

          <TABLE bgcolor="white">
          <TR>
           <TH>Session ID.</TH>
           <TH>Username</TH>
           <TH>Logged on since</TH>
           <TH>Total idle time</TH>
           <TH>Program</TH>
           <TH>Locks present</TH>
           <TH>Last checked on</TH>
          </TR>
      ');

owa_util.cellsprint(v_query3);

htp.prn('
          </TABLE>

<!-- Einde -->

          <br>
        </td>
        <td>&nbsp;</td>
      </tr>
      <td>&nbsp;</td>
    </td>
  </tr>
</table>
</body>
</html>
');
END;
/
 