declare
  i2_found 					number(1) := 0;
  sql_cmd  					varchar2(32000);
BEGIN
  SELECT 1 INTO i2_found FROM user_tables WHERE table_name = 'MAX_FIXED_TABLE_SEQ';
EXCEPTION
WHEN NO_DATA_FOUND THEN
  sql_cmd := 'create table max_fixed_table_seq ('||
					'username				varchar2(30),'||
					'fixed_table_sequence 	number,'||
					'last_run				date,'||
					'comment_last_run		varchar2(4000))'||
				  'tablespace dzdba_dt';
  EXECUTE IMMEDIATE sql_cmd;
  sql_cmd := 'create table idle_session_info ('||
					'sid					number,'||
					'serial                 number,'||
					'username				varchar2(30),'||
					'logon_time				date,'||
					'status                 varchar2(20),'||
					'fixed_table_sequence 	number,'||
					'idle_time				number,'||
					'program				varchar2(48),'||
					'consistent_gets		number,'||
					'last_run				date,'||
					'locks                  varchar2(3),'||
					'last_exec_stat			varchar2(256))'||
				  'tablespace dzdba_dt';
  EXECUTE IMMEDIATE sql_cmd;
WHEN others THEN
  dbms_output.put_line ('Error in build_idle_sess_info (create tabs): '||SQLCODE||' Message: '||substr(SQLERRM,1,100));
  ROLLBACK;
END;
/

create or replace procedure build_idle_sess_info (p_us_name varchar2) as
  i2_found 					number(1) := 0;
  i2_locks_found 			number(3) := 0;
  v_locks_found             varchar2(3);
  sql_cmd  					varchar2(32000);
  select_cmd				varchar2(32000);
  v_us_name					varchar2(30);
  i2_max_fixed_table_seq	number := 0;
  v_sql_last_stat           varchar2(4000);
  v_previous_run			date;
  i2_new_max_fixed_t_seq    number := 0;
  v_error_code				number := 0;
  v_error_tekst				varchar2(255);
  
  CURSOR get_us_sessions(us_name varchar2) IS
    SELECT b.sid, b.serial#, b.username, b.logon_time, b.fixed_table_sequence, b.last_call_et, b.program, 
	       a.consistent_gets, b.prev_sql_addr, b.prev_hash_value, b.status
    FROM v$session b, v$sess_io a
    WHERE b.audsid != sys_context('userenv','sessionid')  -- leave out  this session
    AND b.username = upper(us_name)
    AND a.sid = b.sid
    ORDER BY b.fixed_table_sequence DESC;
	
  CURSOR get_sqltext(p_address RAW, p_hash_value NUMBER) IS
    SELECT sql_text
	FROM v$sqltext_with_newlines
	WHERE address = p_address
	AND   hash_value = p_hash_value
	ORDER BY piece;
	
  TYPE RefCurTyp IS REF CURSOR;
  curs_var					RefCurTyp;
BEGIN
-- Here the main procedure starts
  v_us_name := UPPER(p_us_name);
-- set previous run to yesterday. In case already run previous run will be retrieved correctly from database.
  v_previous_run := SYSDATE-1;

-- Get the maximum FIXED_TABLE_SEQUENCE of the previous run which was stored in table max_fixed_table_seq
-- We'll do this in a sub-routine because there might not be a record present then we have to create it.
  BEGIN
    i2_max_fixed_table_seq := 0;
    SELECT fixed_table_sequence, last_run INTO i2_max_fixed_table_seq, v_previous_run FROM max_fixed_table_seq
	WHERE username = v_us_name;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    INSERT INTO max_fixed_table_seq (username,fixed_table_sequence) VALUES (v_us_name,0);
  WHEN TOO_MANY_ROWS THEN
    DELETE FROM max_fixed_table_seq WHERE username = v_us_name;
    INSERT INTO max_fixed_table_seq (username,fixed_table_sequence) VALUES (v_us_name,0);
  WHEN others THEN
    dbms_output.put_line ('Error in build_idle_sess_info (ins MAX_FIXED_TABLE_SEQ): '||SQLCODE||' Message: '||substr(SQLERRM,1,100));
	i2_max_fixed_table_seq := -1;
    ROLLBACK;
  END;

-- set the new max val equal to the current max val.
  i2_new_max_fixed_t_seq := i2_max_fixed_table_seq;
  
-- If the variable i2_max_fixed_table_seq contains a negative number something went wrong in the above part so stop processing
  IF i2_max_fixed_table_seq >= 0 THEN
    FOR sess_rec IN get_us_sessions(v_us_name) LOOP
	  IF i2_max_fixed_table_seq = 0 THEN
-- If the variable i2_max_fixed_table_seq contains a zero, this means that we start processing for a new user. Insert all
-- the records found for inactive sessions in the table IDLE_SESSION_INFO
		IF sess_rec.status != 'ACTIVE' THEN
-- first get the last SQL statement executed by the session (we do this in a seperate BEGIN-END block).
          v_sql_last_stat := ' ';
          BEGIN
	  	    FOR sqltext_rec IN get_sqltext(sess_rec.prev_sql_addr, sess_rec.prev_hash_value) LOOP
		      IF LENGTH(v_sql_last_stat)+LENGTH(sqltext_rec.sql_text) > 256 THEN
			    EXIT;		-- EXIT the LOOP
  			  END IF;
	  		  v_sql_last_stat := v_sql_last_stat||sqltext_rec.sql_text;
		    END LOOP;
	      EXCEPTION  
          WHEN NO_DATA_FOUND THEN
            NULL;
          WHEN others THEN
            v_error_code := SQLCODE;
			v_error_tekst := substr(SQLERRM,1,100);
  		    ROLLBACK;
		    UPDATE max_fixed_table_seq
            SET    last_run             = SYSDATE,
                   comment_last_run     = 'Error in build_idle_sess_info (get V$SQLTEXT_1): '||v_error_code||' Message: '||v_error_tekst
            WHERE  username = v_us_name;
            COMMIT;
-- 		    dbms_output.put_line ('Error in build_idle_sess_info (get V$SQLTEXT_1): '||SQLCODE||' Message: '||substr(SQLERRM,1,100));
--                    ROLLBACK;
	        i2_max_fixed_table_seq := -1;
		  END;

          IF sess_rec.fixed_table_sequence > i2_new_max_fixed_t_seq THEN
		    i2_new_max_fixed_t_seq := sess_rec.fixed_table_sequence;
		  END IF;

--  Determine if the session holds locks
          i2_locks_found := 0;
          v_locks_found := 'NO';
		  SELECT COUNT(*) INTO i2_locks_found FROM v$lock WHERE sid = sess_rec.sid;
		  IF i2_locks_found > 0 THEN
		    v_locks_found := 'YES';
		  END IF;
		  
          INSERT INTO idle_session_info (sid, serial, username, logon_time, status, fixed_table_sequence, idle_time, program, 
		              consistent_gets, last_run, locks, last_exec_stat)
		  VALUES (sess_rec.sid, sess_rec.serial#, sess_rec.username, sess_rec.logon_time, sess_rec.status, sess_rec.fixed_table_sequence, 
		          sess_rec.last_call_et, sess_rec.program, sess_rec.consistent_gets, SYSDATE, v_locks_found, v_sql_last_stat);
	    END IF;
	  ELSE
-- Here we end up when there has already been a succesfull run of the script for a certain username.
-- In other words when there is a record in MAX_FIXED_TABLE_SEQ
		IF sess_rec.status = 'ACTIVE' THEN

-- If the session is active at this moment check if the record is present in the table idle_session_info and remove the record
          BEGIN
            DELETE FROM idle_session_info where sid = sess_rec.sid and serial = sess_rec.serial#;
		  EXCEPTION
		  WHEN NO_DATA_FOUND THEN
		    NULL;
		  WHEN OTHERS THEN
            v_error_code := SQLCODE;
			v_error_tekst := substr(SQLERRM,1,100);
            ROLLBACK;
		    UPDATE max_fixed_table_seq
            SET    last_run             = SYSDATE,
                   comment_last_run     = 'Error in build_idle_sess_info (del ACTIVE sess): '||v_error_code||' Message: '||v_error_tekst
            WHERE  username = v_us_name;
            COMMIT;
--            dbms_output.put_line ('Error in build_idle_sess_info (del ACTIVE sess): '||SQLCODE||' Message: '||substr(SQLERRM,1,100));
--            ROLLBACK;
	        i2_max_fixed_table_seq := -1;
		  END;
		  
		ELSE
-- first get the last SQL statement executed by the session (we do this in a seperate BEGIN-END block).
          v_sql_last_stat := ' ';
          BEGIN
	  	    FOR sqltext_rec IN get_sqltext(sess_rec.prev_sql_addr, sess_rec.prev_hash_value) LOOP
		      IF LENGTH(v_sql_last_stat)+LENGTH(sqltext_rec.sql_text) > 256 THEN
			    EXIT;		-- EXIT the LOOP
  			  END IF;
	  		  v_sql_last_stat := v_sql_last_stat||sqltext_rec.sql_text;
		    END LOOP;
	      EXCEPTION  
          WHEN NO_DATA_FOUND THEN
            NULL;
          WHEN others THEN
            v_error_code := SQLCODE;
			v_error_tekst := substr(SQLERRM,1,100);
            ROLLBACK;
		    UPDATE max_fixed_table_seq
            SET    last_run             = SYSDATE,
                   comment_last_run     = 'Error in build_idle_sess_info (ins V$SQLTEXT_2): '||v_error_code||' Message: '||v_error_tekst
            WHERE  username = v_us_name;
            COMMIT;
--            dbms_output.put_line ('Error in build_idle_sess_info (ins V$SQLTEXT_2): '||SQLCODE||' Message: '||substr(SQLERRM,1,100));
--            ROLLBACK;
	        i2_max_fixed_table_seq := -1;
		  END;

--  Determine if the session holds locks
          i2_locks_found := 0;
          v_locks_found := 'NO';
		  SELECT COUNT(*) INTO i2_locks_found FROM v$lock WHERE sid = sess_rec.sid;
		  IF i2_locks_found > 0 THEN
		    v_locks_found := 'YES';
		  END IF;

-- Refresh the data of NOT ACTIVE sessions in the table idle_session_info or insert the record if non existent.
          BEGIN
            SELECT 1 INTO i2_found FROM idle_session_info
			WHERE sid = sess_rec.sid
		    AND   serial = sess_rec.serial#;
			
            UPDATE idle_session_info
		    SET status = sess_rec.status,
		        fixed_table_sequence = sess_rec.fixed_table_sequence,
			    idle_time = sess_rec.last_call_et,
			    program = sess_rec.program,
			    consistent_gets = sess_rec.consistent_gets,
			    last_exec_stat = v_sql_last_stat,
				locks = v_locks_found,
				last_run = SYSDATE
		    WHERE sid = sess_rec.sid
		    AND   serial = sess_rec.serial#;

	      EXCEPTION
		  WHEN NO_DATA_FOUND THEN
            INSERT INTO idle_session_info (sid, serial, username, logon_time, status, fixed_table_sequence, idle_time, program, 
		                consistent_gets, last_run, locks, last_exec_stat)
		    VALUES (sess_rec.sid, sess_rec.serial#, sess_rec.username, sess_rec.logon_time, sess_rec.status, sess_rec.fixed_table_sequence, 
		            sess_rec.last_call_et, sess_rec.program, sess_rec.consistent_gets, SYSDATE, v_locks_found, v_sql_last_stat);
		  WHEN OTHERS THEN
            v_error_code := SQLCODE;
			v_error_tekst := substr(SQLERRM,1,100);
            ROLLBACK;
		    UPDATE max_fixed_table_seq
            SET    last_run             = SYSDATE,
                   comment_last_run     = 'Error in build_idle_sess_info (upd SESSION INFO): '||v_error_code||' Message: '||v_error_tekst
            WHERE  username = v_us_name;
			COMMIT;
--            dbms_output.put_line ('Error in build_idle_sess_info (upd SESSION INFO): '||SQLCODE||' Message: '||substr(SQLERRM,1,100));
--	        i2_max_fixed_table_seq := -1;
	        i2_max_fixed_table_seq := -1;
		  END;

          IF sess_rec.fixed_table_sequence > i2_new_max_fixed_t_seq THEN
		    i2_new_max_fixed_t_seq := sess_rec.fixed_table_sequence;
		  END IF;
		  
		END IF;
	  END IF;
    END LOOP;
  END IF;

  IF i2_max_fixed_table_seq >= 0 THEN
-- Remove from the idle_session_info table all records older than 4 days
    DELETE FROM idle_session_info
    WHERE last_run < SYSDATE-4;
  
-- Set the status of all records still in idle_session_info but not anymore in the database to "NOT EXISTS"
    UPDATE idle_session_info
    SET status = 'NOT EXISTS'
    WHERE last_run <= v_previous_run;
  
    UPDATE max_fixed_table_seq
    SET    fixed_table_sequence = i2_new_max_fixed_t_seq,
           last_run             = SYSDATE,
           comment_last_run     = 'Successful run'
    WHERE  username = v_us_name;
  END IF;

  COMMIT;
  
EXCEPTION
WHEN others THEN
  v_error_code := SQLCODE;
  v_error_tekst := substr(SQLERRM,1,100);
  ROLLBACK;
  UPDATE max_fixed_table_seq
  SET    last_run      = SYSDATE,
  comment_last_run     = 'Error in build_idle_sess_info (main): '||v_error_code||' Message: '||v_error_tekst
  WHERE  username = v_us_name;
  COMMIT;
--  dbms_output.put_line ('Error in build_idle_sess_info (main): '||SQLCODE||' Message: '||substr(SQLERRM,1,100));
--  ROLLBACK;
END;
/
