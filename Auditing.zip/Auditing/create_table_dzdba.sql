create table dzdba.audit_last_connection (
   user_name	        varchar2(30) not null,
   last_connection		date) tablespace dzdba_dt;

alter table dzdba.audit_last_connection add constraint audit_last_connection_pk primary key (user_name) using index tablespace dzdba_ix;
   
grant all on audit_last_connection to system;
   