create or replace trigger SYSTEM.FLX_AUDIT_LAST_CONNECTION
AFTER LOGON ON DATABASE
DECLARE
  v_n_teller	NUMBER := 0;
BEGIN
  merge into dzdba.audit_last_connection b
  using ( select USER user_name, SYSDATE last_connection from dual) a
  on (a.user_name = b.user_name)
  when matched then
    update set b.last_connection = a.last_connection
  when not matched then
    insert (b.user_name, b.last_connection)
	values (a.user_name, a.last_connection);
EXCEPTION
  when others then
    v_n_teller := 0;
END;
/
