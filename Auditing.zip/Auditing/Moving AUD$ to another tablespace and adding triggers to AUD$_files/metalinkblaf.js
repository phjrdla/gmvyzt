//******************************
function disableBlafButton(buttonId){
   var buttonBits;
   var left,middle,right;
   var label;

   buttonBits = document.getElementsByName(buttonId);
   if (buttonBits) {
      for (var r=0; r*5<buttonBits.length; r++) {
      // The 5 named elements of a blaf button map to [0] the left anchor, [1] the left image,
      // [2] the middle anchor, [3] the right anchor and [4] the right image.
        left = buttonBits[r*5];
        left.removeAttribute('href');
        left.firstChild.src = 
          left.firstChild.src.replace(
                                    'Standardbutton_left.gif',
                                    'Standardbutton_leftdis.gif');

        middle = buttonBits[r*5+2]; // +2 = the middle anchor
        middle.removeAttribute('href');
        middle.className = "buttonLinkDisblaf-plus";
        middle.parentNode.className = 'buttonDisblaf-plus';

        right = buttonBits[r*5+3]; // +3 = the right anchor
        right.removeAttribute('href');
        right.firstChild.src = 
          right.firstChild.src.replace(
                                    'Standardbutton_right.gif',
                                    'Standardbutton_rightdis.gif');
      }
   }
}
//******************************
function disableBlafButton2(buttonId){
   var buttonBits;
   var left,middle,right;
   var label;

   buttonBits = document.getElementsByName(buttonId);
   if (buttonBits) {
      for (var r=0; r*5<buttonBits.length; r++) {
      // The 5 named elements of a blaf button map to [0] the left anchor, [1] the left image,
      // [2] the middle anchor, [3] the right anchor and [4] the right image.
        left = buttonBits[r*5];
        left.removeAttribute('href');
        left.firstChild.src = 
          left.firstChild.src.replace(
                                    'Standardbutton_left.gif',
                                    'Standardbutton_leftdis.gif');

        middle = buttonBits[r*5+2]; // +2 = the middle anchor
        middle.removeAttribute('href');
        middle.className = "buttonLinkDisblaf-plus";
        middle.parentNode.className = 'buttonDisblaf-plus';

        right = buttonBits[r*5+3]; // +3 = the right anchor
        right.removeAttribute('href');
        right.firstChild.src = 
          right.firstChild.src.replace(
                                    'Standardbutton_right.gif',
                                    'Standardbutton_rightdis.gif');
      }
   }
}
//******************
function enableBlafButton(buttonId, buttonAction){
   var buttonBits;
   var left,middle,right;
   var label;

   buttonBits = document.getElementsByName(buttonId);
   if (buttonBits) {
      for (var r=0; r*5<buttonBits.length; r++) {
      // The 5 named elements of a blaf button map to [0] the left anchor, [1] the left image,
      // [2] the middle anchor, [3] the right anchor and [4] the right image.
        left = buttonBits[r*5];
        left.setAttribute('href', buttonAction);
        left.firstChild.src = 
        left.firstChild.src.replace(
                                 'Standardbutton_leftdis.gif',
                                 'Standardbutton_left.gif');

        middle = buttonBits[r*5+2];
        middle.setAttribute('href', buttonAction);
        middle.className = "buttonLinkblaf-plus";
        middle.parentNode.className = 'buttonMiddleblaf-plus';

        right = buttonBits[r*5+3];
        right.setAttribute('href', buttonAction);
        right.firstChild.src = 
        right.firstChild.src.replace(
                                 'Standardbutton_rightdis.gif',
                                 'Standardbutton_right.gif');
      }
   }
}
//******************************
function setFocusBlafButton(buttonId, index){
   var buttonBits;
   var left,middle,right;
   var label;
   var r;
   
   buttonBits = document.getElementsByName(buttonId);
   if (buttonBits) {
     if (index) { r = index; } else { r = 0; }
     middle = buttonBits[r*5+2];
     if (middle) { middle.focus(); }
   }
}
//******************************
function disableBlafButtons(callType){
if (callType == 'ADDROWS'){
  disableBlafButton('addContact');
  disableBlafButton('addMilestone');
  disableBlafButton('addConfig');
  disableBlafButton('addSupId');
  disableBlafButton('conf');
  disableBlafButton('addMSupId');
  }
}
function removeTheBlue(theFrame){
   if (theFrame.contentDocument){
       var doc = theFrame.contentDocument;
       doc.body.style.backgroundColor ='white';
       for (var i = 0;i<doc.images.length;i++){
         if (doc.images[i].src.indexOf('right')>0||doc.images[i].src.indexOf('left')>0) {
           doc.images[i].src='/i/blank.gif';
         }
       }
   } else {
       var doc = theFrame.document;
       doc.documentElement.style.backgroundColor ='white';
       for (var i = 0;i<doc.images.length;i++){
         if (doc.images[i].src.indexOf('right')>0||doc.images[i].src.indexOf('left')>0) {
           doc.images[i].src='/i/blank.gif';
         }
       }
   }
}
function setIFrameHeight(theFrame){
  if (theFrame.contentDocument){
    theFrame.height = theFrame.contentDocument.body.offsetHeight+30;
    //removeTheBlue(theFrame);
  } else {
    theFrame.height = theFrame.document.documentElement.scrollHeight + 5 + 'px';
    //removeTheBlue(theFrame);
  }
}

//*********Dynamic resizing the iFrame code starts*********//
/***********************************************
* IFrame SSI script II- � Dynamic Drive DHTML code library (http://www.dynamicdrive.com)
* Visit DynamicDrive.com for hundreds of original DHTML scripts
* This notice must stay intact for legal use
***********************************************/

//Input the IDs of the IFRAMES you wish to dynamically resize to match its content height:
//Separate each ID with a comma. Examples: ["myframe1", "myframe2"] or ["myframe"] or [] for none:
var iframeids=["myframe","admini","corner","content"]

//Should script hide iframe from browsers that don't support this script (non IE5+/NS6+ browsers. Recommended):
var iframehide="yes"

var getFFVersion=navigator.userAgent.substring(navigator.userAgent.indexOf("Firefox")).split("/")[1]
var FFextraHeight=parseFloat(getFFVersion)>=0.1? 16 : 0 //extra height in px to add to iframe in FireFox 1.0+ browsers
var FFextraWidth=parseFloat(getFFVersion)>=0.1? 16 : 0 //extra height in px to add to iframe in FireFox 1.0+ browsers

function resizeCaller() {
var dyniframe=new Array()
for (i=0; i<iframeids.length; i++){
if (document.getElementById)
resizeIframe(iframeids[i])
//reveal iframe for lower end browsers? (see var above):
if ((document.all || document.getElementById) && iframehide=="no"){
var tempobj=document.all? document.all[iframeids[i]] : document.getElementById(iframeids[i])
tempobj.style.display="block"
}
}
}

function resizeIframe(frameid)
{
   var currentfr=document.getElementById(frameid);
   var mytab = document.getElementById("plsqlregion");
   var wdth;
   var heightfirst;
   var heightsecond;
   if (currentfr && !window.opera)
   {
      currentfr.style.display="block";
      if (currentfr.contentDocument && currentfr.contentDocument.body.offsetHeight)
      {
         //ns6 syntax
         currentfr.height = currentfr.contentDocument.body.offsetHeight+FFextraHeight;
         wdth = currentfr.contentDocument.body.scrollWidth;
/* commented out for certify issue 
         if(FFextraHeight != 0 && wdth > 1000)
         {
            wdth *= 2;
         }
*/
         //mytab.width = (currentfr.contentDocument.body.scrollWidth)*2;
	 if (mytab){
		 mytab.width = wdth;
	 }
      }
      else if (currentfr.Document && currentfr.Document.body.scrollHeight)
      {
          //ie5+ syntax
         currentfr.height = currentfr.Document.body.scrollHeight;
         //alert(currentfr.Document.body.scrollWidth);
         //currentfr.width  = currentfr.Document.body.scrollWidth;
        wdth = currentfr.Document.body.scrollWidth;
        /* if(wdth > 1950)
         {
            wdth *= 1.28;
         }*/
         //mytab.width = (currentfr.Document.body.scrollWidth)*1.28;
	 if (mytab){
		 mytab.width = wdth;
	 }
      }
      if (currentfr.addEventListener)
      {
	 currentfr.addEventListener("load", readjustIframe, false);
      }
      else if (currentfr.attachEvent)
      {
         currentfr.detachEvent("onload", readjustIframe); // Bug fix line
         currentfr.attachEvent("onload", readjustIframe);
      }
window.scrollTo(0,0);
}

//window.scrollTo(0,document.body.scrollHeight);
}

function readjustIframe(loadevt) {
var crossevt=(window.event)? event : loadevt
var iframeroot=(crossevt.currentTarget)? crossevt.currentTarget : crossevt.srcElement
	if (iframeroot) {
		resizeIframe(iframeroot.id); 
	}
}

if (window.addEventListener)
window.addEventListener("load", resizeCaller, false)
else if (window.attachEvent)
window.attachEvent("onload", resizeCaller)
else
window.onload=resizeCaller

/*********End of dynamic resizing the iFrame*********/
var changed;
function centerWindow(url, name, v_height, v_width) {
  var str1 = "height=" + v_height + ",innerHeight=" + v_height;
  str1 += ",width=" + v_width + ",innerWidth=" + v_width;
  if (window.screen) {
    var ah = screen.availHeight - 30;
    var aw = screen.availWidth - 10;

    var xc = (aw - v_width) / 2;
    var yc = (ah - v_height) / 2;

    str1 += ",left=" + xc + ",screenX=" + xc;
    str1 += ",top=" + yc + ",screenY=" + yc;
    str1 += ",scrollbars=yes,resizable=yes,menubar=yes";
  }
  return window.open(url, name, str1);
}

function popup(url)
{
newwin = centerWindow(url, 'center', 400, 600);
 if (window.focus) {newwin.focus()}
 return false;
}

if (navigator.appName == 'Netscape') {
   window.captureEvents(Event.MOUSEDOWN)
   window.onmousedown = getEvent;
   window.onkeypress = getEventKey;
 } else if (navigator.appName == 'Microsoft Internet Explorer') {
    document.onmousedown=getEvent;
 }

function getEvent(e){
  if (!e) { var e = window.event; }
   if (navigator.appName == 'Microsoft Internet Explorer') {
//alert(e.srcElement.name);
       if (e.srcElement.name != 'CANCEL' && e.srcElement.name != null) {
           if (changed == false) {
            changed = true;
           }
       }         
   } else if (navigator.appName == 'Netscape') {
//alert(e.target.name);
       if (e.target.name != 'CANCEL' && e.target.type != null) {
           if (changed == false) {
             changed = true;
           }
       } 
   }
}

function getEventKey(e){
document.captureEvents(Event.KEYPRESS)
 changed = true;
 }

// start checking to see if this page was changed before canceling.
var errorUp = false;
function nameImage() {
var sorce;
for (var i = 0;i<document.images.length;i++){
	sorce = document.images[i].src;
 		if (sorce.match('inline_error')) { 
		errorUp = true;
		}
	}
}

