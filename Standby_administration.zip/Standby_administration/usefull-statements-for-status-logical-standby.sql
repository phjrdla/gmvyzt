-- On the primary database:

-- Determine the most recent archived redo log file on the primary database.
SELECT MAX(SEQUENCE#), THREAD# FROM V$ARCHIVED_LOG GROUP BY THREAD#;

-- Determine the most recent archived redo log file at each destination.
SELECT DESTINATION, STATUS, ARCHIVED_THREAD#, ARCHIVED_SEQ#
FROM V$ARCHIVE_DEST_STATUS
WHERE STATUS <> 'DEFERRED' AND STATUS <> 'INACTIVE';

-- Find out if archived redo log files have been received.

-- You can issue a query at the primary database to find out if an archived redo log file was not received at a particular site. Each destination has an ID number associated with it. You can query the DEST_ID column of the V$ARCHIVE_DEST fixed view on the primary database to identify each destination's ID number.

-- To identify which log files are missing at the standby destination, issue the following query:

SELECT LOCAL.THREAD#, LOCAL.SEQUENCE# FROM
(SELECT THREAD#, SEQUENCE# FROM V$ARCHIVED_LOG WHERE DEST_ID=1)
LOCAL WHERE
LOCAL.SEQUENCE# NOT IN
(SELECT SEQUENCE# FROM V$ARCHIVED_LOG WHERE DEST_ID=2 AND
THREAD# = LOCAL.THREAD#);

-- On the logical standby database:

-- The DBA_LOGSTDBY_EVENTS view record interesting events that occurred during the operation of SQL Apply
ALTER SESSION SET NLS_DATE_FORMAT  = 'DD-MON-YY HH24:MI:SS';
COLUMN STATUS FORMAT A60;
SELECT EVENT_TIME, STATUS, EVENT FROM DBA_LOGSTDBY_EVENTS
ORDER BY EVENT_TIMESTAMP, COMMIT_SCN;

-- The DBA_LOGSTDBY_LOG view provides dynamic information about archived logs being processed by SQL Apply
COLUMN DICT_BEGIN FORMAT A10;
SET NUMF 9999999999;
SELECT FILE_NAME, SEQUENCE# AS SEQ#, FIRST_CHANGE# AS FCHANGE#, 
       NEXT_CHANGE# AS NCHANGE#, TIMESTAMP, DICT_BEGIN AS BEG, DICT_END AS END, 
       THREAD# AS THR#, APPLIED
FROM DBA_LOGSTDBY_LOG 
ORDER BY SEQUENCE#;

-- The V$LOGSTDBY_STATS view provides information related to the failover characteristics of the logical standby database, including:
--    The time to failover (apply finish time)
--    How current is the committed data in the logical standby database (lag time)
--    What the potential data loss will be in the event of a disaster (potential data loss).
SELECT NAME, VALUE FROM V$LOGSTDBY_STATS;

-- The V$LOGSTDBY_PROCESS view provides information about the current state of the various processes involved with SQL Apply
COLUMN LID FORMAT 9999;
COLUMN SERIAL# FORMAT 999999;
COLUMN SID FORMAT 9999;
SELECT SID, SERIAL#, LOGSTDBY_ID AS LID, SPID, TYPE, HIGH_SCN FROM V$LOGSTDBY_PROCESS
order by HIGH_SCN desc;

COLUMN STATUS FORMAT A40;
SELECT TYPE, STATUS_CODE, STATUS FROM V$LOGSTDBY_PROCESS;

-- This V$LOGSTDBY_PROGRESS view provides detailed information regarding progress made by SQL Apply, including:
--    SCN or time at which all transactions that have been committed on the primary database have been applied 
--                to the logical standby database (applied_scn | applied_time)
--    SCN or time at which SQL Apply would begin reading redo records (restart_scn | restart_time) on restart
--    SCN or time of the latest redo record received on the logical standby database (latest_scn | latest_time)
--    SCN or time of the latest record processed by the BUILDER process (mining_scn | mining_time)
SELECT APPLIED_SCN, LATEST_SCN, MINING_SCN, RESTART_SCN FROM V$LOGSTDBY_PROGRESS;
SELECT APPLIED_TIME, LATEST_TIME, MINING_TIME, RESTART_TIME FROM V$LOGSTDBY_PROGRESS;

-- The V$LOGSTDBY_STATE view provides a synopsis of the current state of SQL Apply, including:
--    The DBID of the primary database (primary_dbid).
--    The LogMiner session ID allocated to SQL Apply (session_id).
--    Whether or not SQL Apply is applying in real time (realtime_apply).
--    Where SQL Apply is currently with regard to loading the LogMiner Multiversioned Data Dictionary, receiving redo from the primary database, and applying redo data (STATE)

COLUMN REALTIME_APPLY FORMAT a15;
COLUMN STATE FORMAT a16;
SELECT * FROM V$LOGSTDBY_STATE;

-- The V$LOGSTDBY_STATS view provides SQL Apply statistics.
COLUMN NAME FORMAT a32;
COLUMN VALUE FORMAT a32;
SELECT * FROM V$LOGSTDBY_STATS;

-- Waiting On Gap State
-- This state occurs when SQL Apply has mined and applied all available redo records, 
-- and is waiting for a new log file (or a missing log file) to be archived by the RFS process.
SELECT STATUS FROM V$LOGSTDBY_PROCESS WHERE TYPE = 'READER';

-- Adjusting the Number of APPLIER Processes
-- Perform the following steps to find out whether adjusting the number of APPLIER processes will help you achieve greater throughput:
--    Determine if APPLIER processes are busy by issuing the following query:
SELECT COUNT(*) AS IDLE_APPLIER
FROM V$LOGSTDBY_PROCESS 
WHERE TYPE = 'APPLIER' and status_code = 16166;

-- Once you are sure there are no idle APPLIER processes, issue the following query to ensure 
-- there is enough work available for additional APPLIER processes if you choose to adjust the number of APPLIERS:
SELECT NAME, VALUE FROM V$LOGSTDBY_STATS
     WHERE NAME LIKE 'transaction%';

-- Adjusting the Number of PREPARER Processes
-- In only rare cases do you need to adjust the number of PREPARER processes. 
-- Before you decide to increase the number of PREPARER processes, ensure the following conditions are true:

--    All PREPARER processes are busy
--    The number of transactions ready to be applied is less than the number of APPLIER processes available
--    There are idle APPLIER processes
SELECT COUNT(*) AS IDLE_PREPARER
FROM V$LOGSTDBY_PROCESS
WHERE TYPE = 'PREPARER' and status_code = 16166;