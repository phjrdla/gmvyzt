--# -----------------------------------------------------------------------------
--#  Attention this file contains shel  commands and SQL commands
--# -----------------------------------------------------------------------------



backup database format '/u01/backup/GFQUAS/standby_backup/backup_%t_s%s_s%p';
backup current controlfile for standby format '/u01/backup/GFQUAS/standby_backup/backup_%t_s%s_s%p';
sql "alter system archive log current";
backup filesperset 10 archivelog all format '/u01/backup/GFQUAS/standby_backup/backup_%t_s%s_s%p';
exit;



scp /u01/backup/GFQUAS/standby_backup/backup* dbqtyhst:/u01/backup/GFQUAS/standby_backup


rman target / auxiliary sys/qmx0225GFQUAS@GFQUAS_STBY

duplicate target database for standby nofilenamecheck dorecover;





ALTER DATABASE DROP LOGFILE GROUP 5;
ALTER DATABASE DROP LOGFILE GROUP 6;
ALTER DATABASE DROP LOGFILE GROUP 7;
ALTER DATABASE DROP LOGFILE GROUP 8;

ALTER DATABASE ADD LOGFILE GROUP 1 ('/u01/redoa/GFQUAS/redo_1_1a.log','/u01/redob/GFQUAS/redo_1_1b.log') size 200m;
ALTER DATABASE ADD LOGFILE GROUP 2 ('/u01/redoa/GFQUAS/redo_1_2a.log','/u01/redob/GFQUAS/redo_1_2b.log') size 200m;
ALTER DATABASE ADD LOGFILE GROUP 3 ('/u01/redoa/GFQUAS/redo_1_3a.log','/u01/redob/GFQUAS/redo_1_3b.log') size 200m;
ALTER DATABASE ADD LOGFILE GROUP 4 ('/u01/redoa/GFQUAS/redo_1_4a.log','/u01/redob/GFQUAS/redo_1_4b.log') size 200m;


CONFIGURE SNAPSHOT CONTROLFILE NAME TO '/u01/backup/GFQUAS/scontrolfile.ctl';
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '/u01/backup/GFQUAS/ctl/%F';

exec dbsec_endescrypt.flx_copy_db_passwords('GFQUAS','GFQUAS_STBY');


create configuration GFQUAS_standby as
primary database is GFQUAS
connect identifier is 'GFQUAS.fluxys.int';

add database GFQUAS_STBY as
connect identifier is 'GFQUAS_STBY.fluxys.int'
maintained as physical;

